### Network-Final-Project ###

How to run:
-----------

SERVER: Locate to "safe_tls.py", then run the command "python safe_tls.py -s localhost.pem "" 1060"

CLIENT: Locate to "async_client.py", then run the command "python async_client.py"

Overview: This will allow you to connect to a localhost server and send 
	  messages.